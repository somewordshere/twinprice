(function initializeBackground(global) {
  const api = global.ExtensionAPI;
  const messages = global.CurrencyMessages;
  const settings = global.CurrencySettingsService;
  const sites = global.CurrencySitePreferences;
  const pageActions = global.CurrencyPageActions;
  const onboarding = global.CurrencyOnboardingService;
  const reviewPrompt = global.CurrencyReviewPrompt;
  const siteReport = global.CurrencySiteReport;

  // The goodbye page follows the popup's language, so its address is set again on
  // install, on browser start and whenever the language setting changes.
  async function refreshUninstallPage() {
    try {
      const { language } = await settings.getGlobalSettings();
      await onboarding.setUninstallPage(language);
    } catch (error) {
      console.error("Could not set the uninstall page.", error);
    }
  }

  api.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "sync" && changes.language) refreshUninstallPage();
  });

  api.runtime.onInstalled.addListener(async (details) => {
    refreshUninstallPage();
    try {
      const supportedCodes = await settings.initializeDefaults();
      await pageActions.initializeContextMenu();
      await sites.reconcile(supportedCodes);
      await onboarding.openOnInstall(details);
    } catch (error) {
      console.error("Twinprice initialization failed.", error);
    }
  });

  api.runtime.onStartup.addListener(() => {
    refreshUninstallPage();
    sites.reconcile().catch((error) => {
      console.error("Could not restore remembered-site preferences.", error);
    });
  });

  api.contextMenus.onClicked.addListener((info, tab) => {
    return pageActions.handleContextMenuClick(info, tab);
  });

  api.commands.onCommand.addListener((command) => {
    return pageActions.handleCommand(command);
  });

  api.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleMessage(message, sender)
      .then(sendResponse)
      .catch((error) => sendResponse({
        ok: false,
        error: error instanceof Error ? error.message : "The request could not be completed."
      }));
    return true;
  });

  async function handleMessage(message, sender) {
    switch (message?.type) {
      case messages.GET_SETTINGS:
        return settings.getSettings(message.origin || sender?.url);
      case messages.UPDATE_SETTINGS:
        return settings.updateSettings(message.payload, message.origin || sender?.url);
      case messages.GET_RATES:
        return global.CurrencyRateService.getRates(message.baseCurrency);
      case messages.GET_RATE_HISTORY:
        return global.CurrencyRateHistoryService.getHistory(
          message.baseCurrency,
          message.quoteCurrency
        );
      case messages.GET_CURRENCIES:
        return settings.getAvailableCurrencies();
      case messages.GET_SITE_STATUS:
        return sites.getStatus(message.origin || sender?.url);
      case messages.REMEMBER_SITE:
        return settings.rememberSite(message.origin || sender?.url);
      case messages.FORGET_SITE:
        return sites.forget(message.origin || sender?.url);
      case messages.ACTIVATE_OPEN_TABS:
        return onboarding.activateOpenTabs();
      case messages.SET_BADGE:
        return pageActions.setBadge(sender?.tab?.id, message.count);
      case messages.RECORD_SUCCESS:
        return reviewPrompt.recordSuccess();
      case messages.GET_REVIEW_PROMPT:
        return reviewPrompt.getState();
      case messages.DISMISS_REVIEW_PROMPT:
        return reviewPrompt.dismiss();
      case messages.MARK_REVIEW_OPENED:
        return reviewPrompt.markRated();
      case messages.REPORT_SITE:
        return siteReport.report(message, sender);
      default:
        return { ok: false, error: "Unknown extension request." };
    }
  }

  global.CurrencyBackground = Object.freeze({ handleMessage });
})(globalThis);
