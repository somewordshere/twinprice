(function initializeCurrencyDetector(global) {
  const {
    CURRENCY_META,
    CURRENCY_CODES,
    CONTEXT_REQUIRED_SYMBOLS
  } = global.CurrencyCatalog;
  const {
    NUMBER_CAPTURE,
    parseLocaleNumber,
    buildMarkerPattern
  } = global.CurrencyNumberParser;
  const SYMBOL_GROUPS = createSymbolGroups();
  const PRICE_MARKER_PATTERNS = new Map();
  const SINGLE_CURRENCY_MARKER_PATTERNS = createSingleCurrencyMarkerPatterns();
  const SHARED_MARKER_GROUPS = SYMBOL_GROUPS.filter((group) => group.currencies.length > 1);
  const SHARED_MARKER_PATTERNS = new Map();
  const MAX_COUNTED_PRICE_MARKERS = 4;
  const OWN_BADGE_SELECTOR = "ccp-conversion[data-ccp-owned='true'] .ccp-badge";
  // The notices page-ui.js draws; converter.js keeps the same list as UI_SELECTOR.
  const OWN_UI_SELECTOR = ".ccp-toast, .ccp-selection-popup, .ccp-page-prompt";
  const HIDDEN_ORIGINAL_SELECTOR = "ccp-conversion[data-ccp-owned='true'] > .ccp-original";
  const HIDDEN_SPLIT_BADGE_SELECTOR =
    "ccp-conversion[data-ccp-owned='true'][data-ccp-appended='true'][data-display-mode='replace']";
  const CURRENCY_CODE_PATTERN = new RegExp(
    `(?<![A-Za-z])(${CURRENCY_CODES.join("|")})(?![A-Za-z])`,
    "g"
  );
  const WORD_LIKE_CURRENCY_CODES = new Set(["AMD", "MAD", "TRY"]);
  // Korean, Japanese and Chinese count large amounts in ten-thousands and
  // hundred-millions: 290만원 is 2,900,000 won and 1.5万円 is 15,000 yen.
  const EAST_ASIAN_NUMBER_UNITS = Object.freeze({ "만": 1e4, "万": 1e4, "억": 1e8, "億": 1e8 });
  const EAST_ASIAN_UNIT_CAPTURE = `([${Object.keys(EAST_ASIAN_NUMBER_UNITS).join("")}])`;
  // A symbol written after the amount must not run on into a word ("5 Rp" is not
  // "5 Rpm"), but Korean and Japanese attach particles straight to it: 6,000원부터
  // is "from 6,000 won" and 1,000円から "from 1,000 yen". A symbol that ends in one
  // of those scripts may therefore be followed by letters, never by digits.
  const SUFFIX_MARKER_END =
    "(?!\\p{N})(?:(?<=[\\p{sc=Han}\\p{sc=Hangul}\\p{sc=Hiragana}\\p{sc=Katakana}])|(?!\\p{L}))";
  // Words that begin with a currency character after a number: 3원칙 is "three
  // principles" and 2원리 "two principles", not prices in won.
  const MARKER_WORD_GUARDS = Object.freeze({ "원": "(?![칙리])" });
  const NON_PRICE_CONTEXT_PATTERN =
    /\b(?:available|availability|delivery|items?|left|quantity|rating|reviews?|stock|stück|stueck|verfügbar|lieferung|anzahl|оцінок|наявност[іи]|товар(?:ів|а)?|залишилось)\b/iu;
  let pageCurrencyDetection = null;

  function resetPageCurrencyDetection() {
    pageCurrencyDetection = null;
  }

  function getPageCurrencyDetection() {
    pageCurrencyDetection ||= detectPageCurrency();
    return pageCurrencyDetection;
  }

  // keepTarget keeps prices already in the target currency, which are normally dropped
  // because there is nothing to convert. Selection uses it to tell "not a price" apart
  // from "already in your currency".
  function findMatchesForContext(text, element, settings, { selection = false, keepTarget = false } = {}) {
    const detection = getPageCurrencyDetection();
    const manualCurrency = settings.fromCurrency !== "AUTO"
      ? settings.fromCurrency
      : null;
    // A chosen source currency still yields to the page: "1,064,700" beside a
    // separate "원" is won, and reading it as the chosen currency put an NZ$ rate
    // on a Korean price.
    const allowBare = manualCurrency
      ? selection || (
        isLikelyStandalonePriceText(text, element) &&
        !hasMarkedPriceInContainer(element, manualCurrency) &&
        !hasMarkedPriceInContainer(element)
      )
      : detection.confidence === "high" && (
        selection || (
          isLikelyStandalonePriceText(text, element) &&
          !hasMarkedPriceInContainer(element)
        )
      );

    return findCurrencyMatches(text, {
      forcedCurrency: manualCurrency,
      allowBare,
      pageDetection: detection
    }).filter((match) =>
      (keepTarget || match.currency !== settings.toCurrency) &&
      (selection || !isLikelyLinkedTitle(text, element, match)) &&
      (
        match.strength !== "code" ||
        !WORD_LIKE_CURRENCY_CODES.has(match.currency) ||
        detection.currency === match.currency ||
        (
          manualCurrency === match.currency &&
          isLikelyPriceElement(element)
        )
      )
    );
  }

  function isLikelyLinkedTitle(text, element, match) {
    const link = element?.closest?.("a[href]");
    if (!link || isLikelyPriceElement(element)) return false;
    const surroundingText = `${text.slice(0, match.index)} ${text.slice(match.index + match.raw.length)}`;
    return (surroundingText.match(/\p{L}{2,}/gu) || []).length >= 2;
  }

  function findCurrencyMatches(
    text,
    { forcedCurrency = null, allowBare = false, pageDetection = getPageCurrencyDetection() } = {}
  ) {
    if (!text?.trim()) {
      return [];
    }

    if (forcedCurrency) {
      const marked = findMarkedMatchesForCurrency(text, forcedCurrency);
      return marked.length
        ? marked
        : allowBare && !findCurrencyMatches(text, { pageDetection }).length
          ? findBareMatches(text, forcedCurrency)
          : [];
    }

    const matches = [];
    const upperText = text.toUpperCase();
    const lowerText = text.toLocaleLowerCase();

    for (const currency of CURRENCY_CODES) {
      if (!upperText.includes(currency)) continue;
      matches.push(...findMatchesWithMarkers(text, [currency], currency, "code"));
    }

    for (const group of SYMBOL_GROUPS) {
      if (!group.lowerMarkers.some((marker) => lowerText.includes(marker))) {
        continue;
      }
      const needsContext = group.needsContext;
      let currency =
        group.currencies.length === 1 && !needsContext
          ? group.currencies[0]
          : null;

      if (
        !currency &&
        pageDetection.currency &&
        pageDetection.confidence !== "low" &&
        group.currencies.includes(pageDetection.currency)
      ) {
        currency = pageDetection.currency;
      }

      if (currency) {
        matches.push(
          ...findMatchesWithMarkers(text, group.markers, currency, "symbol")
        );
      }
    }

    const merged = mergeNonOverlappingMatches(matches);

    if (!merged.length && allowBare && pageDetection.currency) {
      return findBareMatches(text, pageDetection.currency);
    }

    return merged;
  }

  function findMarkedMatchesForCurrency(text, currency) {
    const meta = CURRENCY_META[currency];

    if (!meta) {
      return findMatchesWithMarkers(text, [currency], currency, "code");
    }

    return mergeNonOverlappingMatches([
      ...findMatchesWithMarkers(text, [currency], currency, "code"),
      ...findMatchesWithMarkers(text, priceSymbols(meta), currency, "symbol")
    ]);
  }

  function priceSymbols(meta) {
    return [...(meta?.symbols || []), ...(meta?.sharedSymbols || [])];
  }

  function hasCurrencyMarker(text, currency) {
    const markers = [currency, ...priceSymbols(CURRENCY_META[currency])];
    const markerPattern = [...new Set(markers)]
      .map(buildMarkerPattern)
      .sort((a, b) => b.length - a.length)
      .join("|");
    return Boolean(markerPattern && new RegExp(`(?:${markerPattern})`, "iu").test(text || ""));
  }

  function findMatchesWithMarkers(text, markers, currency, strength) {
    const markerPattern = [...new Set(markers)]
      .map((marker) => priceMarkerPattern(marker, currency))
      .sort((a, b) => b.length - a.length)
      .join("|");

    if (!markerPattern) {
      return [];
    }

    const regex = new RegExp(
      `(?:(?<![\\p{N}.,，．\\u066b\\u066c+\\-−])([+\\-−]?)\\s*(?:${markerPattern})[\\s\\u00a0\\u202f]*${NUMBER_CAPTURE}(?![\\p{L}\\p{N}.,，．\\u066b\\u066c+\\-−])|(?<![\\p{L}\\p{N}.,，．\\u066b\\u066c+\\-−])${NUMBER_CAPTURE}[\\s\\u00a0\\u202f]*(?:${EAST_ASIAN_UNIT_CAPTURE}[\\s\\u00a0\\u202f]*)?(?:${markerPattern})${SUFFIX_MARKER_END})`,
      "giu"
    );
    const results = [];
    let found;

    while ((found = regex.exec(text)) !== null) {
      const number = parseLocaleNumber(`${found[1] || ""}${found[2] || found[3]}`, {
        allowThreeDecimals: CurrencyCatalog.currencyFractionDigits(currency) === 3
      });
      const amount = found[4] ? number * EAST_ASIAN_NUMBER_UNITS[found[4]] : number;

      if (Number.isFinite(amount)) {
        results.push({
          raw: found[0],
          amount,
          currency,
          index: found.index,
          strength
        });
      }
    }

    return results;
  }

  function priceMarkerPattern(marker, currency) {
    const key = `${currency}:${marker}`;
    if (PRICE_MARKER_PATTERNS.has(key)) return PRICE_MARKER_PATTERNS.get(key);
    // A short symbol must not match inside an explicit foreign marker, e.g.
    // USD's "$" in "CA$". Preserve symbols beside non-Latin labels such as 価格￥.
    const prefixes = Object.entries(CURRENCY_META).flatMap(([code, meta]) => code === currency ? [] :
      meta.symbols.filter((other) => other.length > marker.length && other.endsWith(marker))
        .map((other) => other.slice(0, -marker.length).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
    );
    const pattern = `${prefixes.length ? `(?<!${[...new Set(prefixes)].join("|")})` : ""}${buildMarkerPattern(marker)}${MARKER_WORD_GUARDS[marker] || ""}`;
    PRICE_MARKER_PATTERNS.set(key, pattern);
    return pattern;
  }

  function findBareMatches(text, currency) {
    const regex = new RegExp(
      `(?<![\\p{L}\\p{N}.,，．\\u066b\\u066c+\\-−])${NUMBER_CAPTURE}(?![\\p{L}\\p{N}.,，．\\u066b\\u066c+\\-−])`,
      "gu"
    );
    const results = [];
    let found;

    while ((found = regex.exec(text)) !== null) {
      const before = text.slice(0, found.index).trimEnd();
      const after = text.slice(found.index + found[0].length).trimStart();

      if (before.endsWith("%") || after.startsWith("%")) {
        continue;
      }

      const amount = parseLocaleNumber(found[1], {
        allowThreeDecimals: CurrencyCatalog.currencyFractionDigits(currency) === 3
      });

      if (Number.isFinite(amount)) {
        results.push({
          raw: found[0],
          amount,
          currency,
          index: found.index,
          strength: "bare"
        });
      }
    }

    return results;
  }

  function mergeNonOverlappingMatches(matches) {
    const strength = { code: 3, symbol: 2, bare: 1 };
    const sorted = [...matches].sort((a, b) =>
      a.index - b.index ||
      strength[b.strength] - strength[a.strength] ||
      b.raw.length - a.raw.length
    );
    const merged = [];

    for (const match of sorted) {
      const overlaps = merged.some((existing) =>
        match.index < existing.index + existing.raw.length &&
        existing.index < match.index + match.raw.length
      );

      if (!overlaps) {
        merged.push(match);
      }
    }

    return merged.sort((a, b) => a.index - b.index);
  }

  function detectPageCurrency() {
    const scores = Object.fromEntries(CURRENCY_CODES.map((code) => [code, 0]));
    const signals = Object.fromEntries(CURRENCY_CODES.map((code) => [code, []]));
    const add = (currency, points, signal) => {
      if (!scores[currency]) scores[currency] = 0;
      if (!signals[currency]) signals[currency] = [];
      scores[currency] += points;
      signals[currency].push(signal);
    };

    const selectors = [
      "meta[itemprop='priceCurrency']",
      "meta[property='product:price:currency']",
      "meta[name='priceCurrency']",
      "[itemprop='priceCurrency']",
      "[data-currency]",
      "input[name='currencyCode']",
      "input[name$='[currencyCode]']",
      "input[id='currencyCode']",
      "input[id$='[currencyCode]']"
    ];

    for (const element of document.querySelectorAll(selectors.join(","))) {
      const value =
        element.getAttribute("content") ||
        element.getAttribute("data-currency") ||
        element.getAttribute("value") ||
        element.textContent;
      const currency = normalizeCurrencyCode(value);
      if (currency) add(currency, 100, "structured metadata");
    }

    for (const script of document.querySelectorAll("script[type='application/ld+json']")) {
      try {
        collectStructuredCurrencies(JSON.parse(script.textContent), (currency) => {
          add(currency, 100, "JSON-LD priceCurrency");
        });
      } catch (_error) {
        // Ignore invalid third-party JSON-LD.
      }
    }

    const embeddedPattern =
      /["'](?:priceCurrency|currencyCode|currency)["']\s*:\s*["']([A-Z]{3})["']/gi;
    const embeddedSources = document.querySelectorAll(
      "script:not([type='application/ld+json'])"
    );

    let inspectedScriptCharacters = 0;
    for (const script of embeddedSources) {
      if (inspectedScriptCharacters >= 500000) break;
      const source = script.textContent?.slice(0, 100000) || "";
      inspectedScriptCharacters += source.length;
      let embedded;
      while ((embedded = embeddedPattern.exec(source)) !== null) {
        const currency = normalizeCurrencyCode(embedded[1]);
        if (currency) add(currency, 75, "embedded shop data");
      }
      embeddedPattern.lastIndex = 0;
    }

    addLocationSignals(add);
    const bodyText = shopTextOf(document.body).slice(0, 100000);
    const codeCounts = {};
    let visibleCode;
    CURRENCY_CODE_PATTERN.lastIndex = 0;
    while ((visibleCode = CURRENCY_CODE_PATTERN.exec(bodyText)) !== null) {
      // "AMD Ryzen", and "Try it free" in a capitalised button (innerText applies
      // text-transform), are words, even right after a price ("$899.00 AMD Radeon").
      // Like a context-required symbol, such a code only corroborates a currency
      // the metadata, domain or language already named.
      if (WORD_LIKE_CURRENCY_CODES.has(visibleCode[1]) && !scores[visibleCode[1]]) continue;
      codeCounts[visibleCode[1]] = (codeCounts[visibleCode[1]] || 0) + 1;
    }
    for (const [currency, count] of Object.entries(codeCounts)) {
      add(currency, Math.min(30, count * 10), "visible currency code");
    }
    addVisiblePriceMarkerSignals(bodyText, scores, add);

    const ranked = Object.entries(scores).sort((a, b) => b[1] - a[1]);
    const [currency, score] = ranked[0];
    const secondScore = ranked[1]?.[1] || 0;
    const confidence =
      score >= 70 && score >= secondScore + 20
        ? "high"
        : score >= 30 && score >= secondScore + 10
          ? "medium"
          : "low";

    return {
      currency: score > 0 ? currency : null,
      confidence,
      score,
      signals: currency ? signals[currency] : []
    };
  }

  // The page's visible text as the shop wrote it. Detection runs again whenever the
  // page changes, by then over our own output: "≈ 25,00 €" badges and notices such
  // as "Detected: TRY" counted as the page's prices and codes, and converted-only
  // mode hid the shop's "1.250,00 TL" from innerText. A lira page then read as euro
  // and the next lira price it loaded did not convert.
  function shopTextOf(body) {
    const text = body?.innerText || "";
    const own = body?.querySelectorAll?.(`${OWN_BADGE_SELECTOR}, ${OWN_UI_SELECTOR}`) || [];
    if (!own.length) return text;
    // innerText lists the page in document order, as querySelectorAll does, so each
    // piece of our own text is found after the previous one.
    let shopText = "";
    let from = 0;
    for (const element of own) {
      // A hidden badge is not in the page's innerText, but its own innerText still
      // returns its text, and searching for it could skip past badges that are.
      if (!element.getClientRects().length) continue;
      const ownText = element.innerText;
      const at = ownText ? text.indexOf(ownText, from) : -1;
      if (at < 0) continue;
      shopText += text.slice(from, at);
      from = at + ownText.length;
    }
    shopText += text.slice(from);
    const hidden = [...body.querySelectorAll(HIDDEN_ORIGINAL_SELECTOR)]
      .filter((original) => original.style.display === "none")
      .map((original) => original.textContent);
    // A split price in converted-only mode keeps its own nodes in place but hides
    // them, so innerText leaves those out too.
    for (const badge of body.querySelectorAll(HIDDEN_SPLIT_BADGE_SELECTOR)) {
      const host = badge.parentElement;
      if (!host) continue;
      hidden.push([...host.childNodes].filter((node) => node !== badge)
        .map((node) => node.textContent).join(""));
    }
    // First, so the length cap applied by the caller cannot cut them off.
    return hidden.length ? `${hidden.join("\n")}\n${shopText}` : shopText;
  }

  // Prices written with a symbol rather than an ISO code are the only currency
  // evidence many storefronts give: a Turkish page says "249,90 TL" and never
  // "TRY". Counting those markers is what lets a context-required symbol resolve
  // at all, so it stays deliberately conservative — unambiguous markers score on
  // their own, ambiguous ones only corroborate a currency another signal named.
  function addVisiblePriceMarkerSignals(bodyText, scores, add) {
    if (!bodyText) return;
    const lowerBodyText = bodyText.toLocaleLowerCase();
    for (const { currency, needsContext, lowerMarkers, pattern } of SINGLE_CURRENCY_MARKER_PATTERNS) {
      if (needsContext && !scores[currency]) continue;
      // A substring test first: without it every currency absent from the page
      // still costs a full regex pass over the body text.
      if (!lowerMarkers.some((marker) => lowerBodyText.includes(marker))) continue;
      pattern.lastIndex = 0;
      let count = 0;
      while (count < MAX_COUNTED_PRICE_MARKERS && pattern.exec(bodyText) !== null) count += 1;
      if (!count) continue;
      // A corroborated marker is worth more per occurrence than an unambiguous
      // one, which reads backwards until you notice what the gate above already
      // did: the page independently named this currency, so each priced "TL" only
      // has to confirm that, not discover it. Weighting it like a first sighting
      // left product pages — one price, not a grid of them — unresolvable, which
      // is the whole case the marker signal exists to serve.
      add(currency, Math.min(30, count * (needsContext ? 15 : 10)), "visible price marker");
    }

    // A shared symbol such as "$" cannot name a currency, but a page full of "$8.97"
    // confirms the dollar its language or domain already suggested. Without this,
    // amazon.com, whose only other evidence is lang="en-us", stayed at low confidence
    // and none of its "$" prices converted. Only a currency that exactly one other
    // signal named is corroborated, so the symbol never picks between candidates.
    const namedScores = { ...scores };
    for (const group of SHARED_MARKER_GROUPS) {
      const named = group.currencies.filter((currency) => namedScores[currency] > 0);
      if (named.length !== 1) continue;
      if (!group.lowerMarkers.some((marker) => lowerBodyText.includes(marker))) continue;
      const pattern = sharedMarkerPattern(group, named[0]);
      pattern.lastIndex = 0;
      let count = 0;
      while (count < MAX_COUNTED_PRICE_MARKERS && pattern.exec(bodyText) !== null) count += 1;
      if (count) add(named[0], Math.min(30, count * 15), "visible price marker");
    }
  }

  // The same marker rules as conversion (priceMarkerPattern), so "$" does not count
  // the dollar inside "CA$" or "NZ$".
  function sharedMarkerPattern(group, currency) {
    const key = `${currency}:${group.lowerMarkers.join("|")}`;
    if (SHARED_MARKER_PATTERNS.has(key)) return SHARED_MARKER_PATTERNS.get(key);
    const markerPattern = [...new Set(group.markers)]
      .map((marker) => priceMarkerPattern(marker, currency))
      .sort((a, b) => b.length - a.length)
      .join("|");
    const pattern = new RegExp(
      `(?:${markerPattern})[\\s\\u00a0\\u202f]*[0-9０-９]|[0-9０-９][\\s\\u00a0\\u202f]*(?:${markerPattern})`,
      "giu"
    );
    SHARED_MARKER_PATTERNS.set(key, pattern);
    return pattern;
  }

  function createSingleCurrencyMarkerPatterns() {
    return SYMBOL_GROUPS
      .filter((group) => group.currencies.length === 1)
      .map((group) => ({
        currency: group.currencies[0],
        needsContext: group.needsContext,
        lowerMarkers: group.lowerMarkers,
        pattern: buildPriceMarkerPattern(group.markers)
      }));
  }

  function buildPriceMarkerPattern(markers) {
    const markerPattern = [...new Set(markers)]
      .map(buildMarkerPattern)
      .sort((a, b) => b.length - a.length)
      .join("|");
    return new RegExp(
      `(?:${markerPattern})[\\s\\u00a0\\u202f]*[0-9０-９]|[0-9０-９][\\s\\u00a0\\u202f]*(?:${markerPattern})`,
      "giu"
    );
  }

  function addLocationSignals(add) {
    const language = document.documentElement.lang?.toLowerCase() || "";
    const domainMap = {
      ch: "CHF", jp: "JPY", cn: "CNY", uk: "GBP", pl: "PLN", cz: "CZK",
      tr: "TRY", in: "INR", kr: "KRW", br: "BRL", ca: "CAD", au: "AUD",
      nz: "NZD", sg: "SGD", hk: "HKD", mx: "MXN", se: "SEK", no: "NOK",
      dk: "DKK", za: "ZAR", us: "USD", ua: "UAH", ro: "RON", hu: "HUF",
      il: "ILS", th: "THB", id: "IDR", my: "MYR", ph: "PHP", vn: "VND",
      tw: "TWD", pk: "PKR", bd: "BDT", lk: "LKR", ng: "NGN", ke: "KES",
      eg: "EGP", ma: "MAD", qa: "QAR", kw: "KWD", bh: "BHD", om: "OMR",
      jo: "JOD", ge: "GEL", am: "AMD", az: "AZN", kz: "KZT", ae: "AED",
      sa: "SAR", ar: "ARS"
    };
    // Croatia has used the euro since 2023 and Bulgaria since 2026-01-01.
    const euroDomains = new Set([
      "de", "fr", "es", "it", "nl", "at", "be", "ie", "pt", "fi", "gr",
      "sk", "si", "ee", "lv", "lt", "lu", "cy", "mt", "hr", "bg"
    ]);
    const addDomainSignal = (host, points, signal) => {
      const tld = host.toLowerCase().split(".").pop();
      const currency = euroDomains.has(tld) ? "EUR" : domainMap[tld];
      if (currency) add(currency, points, signal);
    };

    const currentHost = window.location.hostname;
    if (currentHost) addDomainSignal(currentHost, 20, "country domain");
    // Alquiler Argentina lists prices in pesos on a .com with lang="es".
    if (currentHost === "alquilerargentina.com" || currentHost === "www.alquilerargentina.com") {
      add("ARS", 40, "site currency");
    }

    const canonicalUrl = document.querySelector("link[rel='canonical']")?.href;
    if (canonicalUrl) {
      try {
        const canonicalHost = new URL(canonicalUrl, window.location.href).hostname;
        if (canonicalHost && canonicalHost !== currentHost) {
          addDomainSignal(canonicalHost, 40, "canonical country domain");
        }
      } catch (_error) {
        // Ignore malformed third-party canonical URLs.
      }
    }

    const region = language.match(/-([a-z]{2})\b/)?.[1];
    let languageCurrency = domainMap[region];
    const languagePrefixes = {
      ja: "JPY", ko: "KRW", pl: "PLN", cs: "CZK", tr: "TRY", uk: "UAH",
      ro: "RON", hu: "HUF", he: "ILS", th: "THB", id: "IDR", ms: "MYR",
      vi: "VND", ka: "GEL", hy: "AMD", az: "AZN", kk: "KZT", hr: "EUR", bg: "EUR"
    };
    languageCurrency ||= languagePrefixes[language.split("-")[0]];
    if (languageCurrency) add(languageCurrency, 15, "page language");
  }

  function collectStructuredCurrencies(value, callback) {
    if (!value || typeof value !== "object") return;

    if (typeof value.priceCurrency === "string") {
      const currency = normalizeCurrencyCode(value.priceCurrency);
      if (currency) callback(currency);
    }

    for (const child of Object.values(value)) {
      if (child && typeof child === "object") {
        collectStructuredCurrencies(child, callback);
      }
    }
  }

  function normalizeCurrencyCode(value) {
    const code = String(value || "").trim().toUpperCase();
    return CURRENCY_CODES.includes(code) ? code : null;
  }

  function isLikelyPriceElement(element) {
    let current = element;

    for (let level = 0; current && level < 2; level += 1, current = current.parentElement) {
      const attributes = [
        current.id,
        current.className,
        current.getAttribute?.("data-testid"),
        current.getAttribute?.("data-test"),
        current.getAttribute?.("itemprop"),
        current.getAttribute?.("aria-label")
      ]
        .filter((value) => typeof value === "string")
        .join(" ");

      if (/(availability|delivery|quantity|rating|review|stock|inventory)/i.test(attributes)) {
        return false;
      }

      if (/(price|pricing|preis|amount|cost|subtotal|total|summe)/i.test(attributes)) {
        return true;
      }
    }

    return false;
  }

  function isLikelyStandalonePriceText(text, element) {
    const trimmed = text?.trim();
    if (
      !trimmed ||
      trimmed.length > 40 ||
      NON_PRICE_CONTEXT_PATTERN.test(trimmed) ||
      /[A-Za-z\p{L}]{2,}/u.test(trimmed) ||
      isFollowedByPercentSign(trimmed, element)
    ) {
      return false;
    }

    return isLikelyPriceElement(element);
  }

  // React writes a discount as "37<!-- -->%": the "%" sits in the next text node,
  // where the bare-number check cannot see it.
  function isFollowedByPercentSign(text, element) {
    const elementText = element?.textContent || "";
    const at = elementText.indexOf(text);
    return at >= 0 && elementText.slice(at + text.length).trimStart().startsWith("%");
  }

  function hasMarkedPriceInContainer(element, forcedCurrency = null) {
    const text = siteTextOf(element?.parentElement).trim();
    if (!text || text.length > 100) return false;

    return findCurrencyMatches(text, {
      forcedCurrency,
      allowBare: false,
      pageDetection: getPageCurrencyDetection()
    }).length > 0;
  }

  // The container's text without our own "≈ 2 560 000,00 zł" badges. Read with
  // them, a converted price made its block look priced in the target currency,
  // and a sibling price the shop re-rendered afterwards was refused. Reading stops
  // once the trimmed text is too long to accept, which more text cannot undo; a
  // cap on the raw length stopped inside an indented block's leading whitespace,
  // before its "원".
  function siteTextOf(container) {
    if (!container?.querySelector?.(OWN_BADGE_SELECTOR)) return container?.textContent || "";
    const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
    let text = "";
    while (walker.nextNode()) {
      if (walker.currentNode.parentElement?.closest(OWN_BADGE_SELECTOR)) continue;
      text += walker.currentNode.nodeValue;
      if (text.trim().length > 100) break;
    }
    return text;
  }

  function describeDetectedCurrencies(...planGroups) {
    const currencies = new Set();
    for (const plans of planGroups) {
      for (const plan of plans) {
        for (const match of plan.matches) currencies.add(match.currency);
      }
    }
    return [...currencies].join(", ") || "none";
  }

  function createSymbolGroups() {
    const groups = new Map();
    for (const [currency, meta] of Object.entries(CURRENCY_META)) {
      for (const symbol of priceSymbols(meta)) {
        const key = symbol.toLocaleLowerCase();
        const group = groups.get(key) ||
          { markers: [], lowerMarkers: [], currencies: [], needsContext: false };
        group.markers.push(symbol);
        group.lowerMarkers.push(key);
        group.needsContext ||= CONTEXT_REQUIRED_SYMBOLS.has(key);
        if (!group.currencies.includes(currency)) group.currencies.push(currency);
        groups.set(key, group);
      }
    }
    return [...groups.values()];
  }

  global.CurrencyDetector = Object.freeze({
    resetPageCurrencyDetection,
    getPageCurrencyDetection,
    findMatchesForContext,
    findCurrencyMatches,
    hasCurrencyMarker,
    isLikelyPriceElement,
    describeDetectedCurrencies
  });
})(globalThis);
