(function initializePageConverter(global) {
  const t = (key, params) => global.CurrencyI18n.t(key, params);
  const SKIP_TAGS = new Set([
    "SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "INPUT", "SELECT", "OPTION",
    "CODE", "PRE", "SVG", "CANVAS"
  ]);
  const OWNED_SELECTOR = "ccp-conversion[data-ccp-owned='true']";
  const UI_SELECTOR = ".ccp-toast, .ccp-selection-popup, .ccp-page-prompt";
  const MAX_TEXT_NODES_PER_SCAN = 5000;
  const MAX_TEXT_NODES_INSPECTED_PER_SCAN = 20000;
  const MAX_SPLIT_CANDIDATES_PER_SCAN = 1000;
  const MAX_SHADOW_HOSTS_PER_SCAN = 10000;
  const MAX_PENDING_ROOTS = 100;
  const DOM_WRITE_BATCH_SIZE = 200;
  const MAX_DISCOVERY_TEXT_NODES = 6000;
  const MAX_DISCOVERY_PRICE_ELEMENTS = 300;
  const POSSIBLE_PRICE_TEXT_PATTERN = /[0-9０-９٠-٩۰-۹]/;
  const QUICK_CURRENCY_MARKER_PATTERN = new RegExp(
    [...new Set(Object.entries(CurrencyCatalog.CURRENCY_META).flatMap(([currency, meta]) =>
      [currency, ...meta.symbols]
    ))]
      .map(CurrencyNumberParser.buildMarkerPattern)
      .sort((a, b) => b.length - a.length)
      .join("|") + "|(?<![A-Za-z])[A-Z]{3}(?![A-Za-z])",
    "u"
  );
  const PRICE_FRAGMENT_SELECTOR = [
    ".a-offscreen",
    ".a-price-symbol",
    ".a-price-whole",
    ".a-price-decimal",
    ".a-price-fraction"
  ].join(",");
  const SPLIT_CANDIDATE_SELECTOR = [
    "[itemprop*='price' i]",
    "[class*='price' i]",
    "[id*='price' i]",
    "[data-price]",
    "[data-testid*='price' i]",
    "[aria-label*='price' i]"
  ].join(",");
  const SPLIT_INTEGER_PATTERN = /^\d+(?:[\s .']\d{3})*$/u;
  const SPLIT_FRACTION_START_PATTERN = /^\s*\d{2}(?!\d)/u;
  const SPLIT_PART_CLASS_PATTERN =
    /(?:^|[-_\s])(?:major|minor|int|integer|dec|decimal|whole|fraction|frac|cents?)(?=$|[-_\s])/i;

  let settings = null;
  let activeRatesByBase = {};
  let activeRateMetaByBase = {};
  let currentConversion = null;
  let queuedConversion = null;
  let conversionGeneration = 0;
  let discoveryCallback = null;
  let watchedConversionListener = null;
  let observedUrl = window.location.href;
  let splitPriceRecords = new WeakMap();
  // Badge → the inline styles it set to hide a split price's own nodes. A Map, not
  // a WeakMap, so clearing can reach badges the shop already took off the page.
  const hiddenOriginals = new Map();
  const conversionRegistry = CurrencyConversionRegistry.create({
    restoreWrapper: (wrapper) => {
      releaseOriginalContent(wrapper);
      CurrencyConversionRegistry.restoreConvertedWrapper(wrapper);
    },
    updateWrapperPresentation: updateConvertedPresentation
  });
  const discoveryScheduler = CurrencyMutationRootScheduler.create({
    rootProvider: () => document.body,
    onFlush: inspectDiscoveryRoots,
    onError: () => {},
    shouldIgnore: isOwnedElement,
    maxPendingRoots: MAX_PENDING_ROOTS,
    maxShadowHosts: MAX_SHADOW_HOSTS_PER_SCAN,
    idleTimeout: 300,
    fallbackDelay: 75
  });
  const conversionScheduler = CurrencyMutationRootScheduler.create({
    rootProvider: () => document.body,
    onFlush: convertMutationRoots,
    onBeforeMutations: handleObservedMutations,
    onError: () => {},
    shouldIgnore: isOwnedElement,
    maxPendingRoots: MAX_PENDING_ROOTS,
    maxShadowHosts: MAX_SHADOW_HOSTS_PER_SCAN,
    idleTimeout: 750,
    fallbackDelay: 150
  });

  function configure(nextSettings) {
    cancelPendingConversion();
    settings = Object.freeze({ ...nextSettings });
    activeRatesByBase = {};
    activeRateMetaByBase = {};
  }

  function updatePresentation(nextSettings) {
    if (!settings) {
      settings = Object.freeze({ ...nextSettings });
      return;
    }
    const presentation = Object.fromEntries(CurrencySettings.PRESENTATION_KEYS.map((key) => [
      key,
      nextSettings[key]
    ]));
    settings = Object.freeze({ ...settings, ...presentation });
    conversionRegistry.updatePresentation(settings);
  }

  function runSiteConversion(options = {}) {
    if (!settings?.enabled) {
      return Promise.resolve({ ok: false, error: t("error.off") });
    }

    const request = createConversionRequest(options);
    if (!currentConversion || currentConversion.generation !== request.generation) {
      return startConversionRequest(request);
    }
    if (conversionRequestCovers(currentConversion, request)) return currentConversion.promise;
    return enqueueConversionRequest(request);
  }

  function createConversionRequest(options = {}) {
    const roots = options.roots || null;
    return {
      generation: conversionGeneration,
      runSettings: settings,
      fullScan: roots === null,
      clearExisting: options.clearExisting !== false,
      observe: options.observe !== false,
      roots,
      waiters: []
    };
  }

  function startConversionRequest(request) {
    const task = { ...request, promise: null };
    task.promise = performConversion({
      clearExisting: request.clearExisting,
      observe: request.observe,
      roots: request.roots
    }, request.generation, request.runSettings).finally(() => {
      if (currentConversion !== task) return;
      currentConversion = null;
      startQueuedConversion(request.generation);
    });
    currentConversion = task;
    return task.promise;
  }

  function conversionRequestCovers(active, request) {
    return active.fullScan && request.fullScan &&
      (active.clearExisting || !request.clearExisting) &&
      (active.observe || !request.observe);
  }

  function enqueueConversionRequest(request) {
    if (!queuedConversion || queuedConversion.generation !== request.generation) {
      queuedConversion = { ...request, roots: request.roots ? new Set(request.roots) : null, waiters: [] };
    } else {
      queuedConversion.clearExisting ||= request.clearExisting;
      queuedConversion.observe ||= request.observe;
      if (request.fullScan) {
        queuedConversion.fullScan = true;
        queuedConversion.roots = null;
      } else if (!queuedConversion.fullScan) {
        for (const root of request.roots || []) queuedConversion.roots.add(root);
      }
    }
    return new Promise((resolve, reject) => {
      queuedConversion.waiters.push({ resolve, reject });
    });
  }

  function startQueuedConversion(completedGeneration) {
    const request = queuedConversion;
    if (!request || request.generation !== completedGeneration) return;
    queuedConversion = null;
    if (!isCurrentRun(request.generation, request.runSettings)) {
      const result = cancelledConversionResult();
      for (const waiter of request.waiters) waiter.resolve(result);
      return;
    }
    if (request.roots instanceof Set) request.roots = [...request.roots];
    startConversionRequest(request).then(
      (result) => request.waiters.forEach((waiter) => waiter.resolve(result)),
      (error) => request.waiters.forEach((waiter) => waiter.reject(error))
    );
  }

  async function performConversion({
    clearExisting = true,
    observe = true,
    roots = null
  } = {}, generation, runSettings) {
    if (!isCurrentRun(generation, runSettings)) return cancelledConversionResult();
    if (clearExisting) removeConversionsOnly();
    const scanRoots = normalizeRoots(roots || [document.body]);
    const textScan = collectTextNodes(scanRoots);
    const textPlans = textScan.nodes
      .map((node) => ({
        node,
        originalText: node.nodeValue,
        matches: CurrencyDetector.findMatchesForContext(
          node.nodeValue,
          node.parentElement,
          settings
        )
      }))
      .filter((plan) => plan.matches.length);
    const splitPlans = collectSplitPricePlans(scanRoots, textScan.splitCandidates);
    const bases = collectSourceCurrencies(textPlans, splitPlans);

    if (bases.size === 0) {
      if (observe && isCurrentRun(generation, runSettings)) startWatching();
      return buildNoMatchesResult(textPlans, splitPlans);
    }

    const baseList = [...bases];
    const rateResults = await Promise.all(baseList.map(ensureRates));
    if (!isCurrentRun(generation, runSettings)) return cancelledConversionResult();
    const rateError = rateResults.find((result) => !result.ok);
    const failedBases = baseList.filter((_base, index) => !rateResults[index].ok);
    const applied = await applyPlansInBatches(
      textPlans,
      splitPlans,
      generation,
      runSettings
    );
    if (applied.cancelled || !isCurrentRun(generation, runSettings)) {
      return cancelledConversionResult();
    }
    const count = applied.count;
    conversionScheduler.discardRecords();
    if (observe) startWatching();

    const usedMeta = baseList
      .filter((base) => !failedBases.includes(base))
      .map((base) => activeRateMetaByBase[base])
      .filter(Boolean);
    // When some currencies converted and another's rates failed, the result is a
    // success, and those prices were left as they were without a word. Name them.
    const rateFailure = count > 0 && failedBases.length
      ? `${failedBases.join(", ")}: ${rateError.error || t("convert.ratesFailed")}`
      : null;
    return {
      ok: count > 0,
      count,
      detectedCurrency: CurrencyDetector.getPageCurrencyDetection().currency,
      detectionConfidence: CurrencyDetector.getPageCurrencyDetection().confidence,
      detectedCurrencies: CurrencyDetector.describeDetectedCurrencies(textPlans, splitPlans),
      rateDate: usedMeta.map((meta) => meta.date).filter(Boolean).sort().at(-1) || null,
      staleRates: usedMeta.some((meta) => meta.stale),
      rateProvider: [...new Set(usedMeta.map((meta) => meta.provider).filter(Boolean))].join(", ") || null,
      cacheAgeLabel: cacheAgeLabel(usedMeta
        .filter((meta) => meta.stale && Number.isFinite(meta.cacheAgeMs))
        .sort((a, b) => b.cacheAgeMs - a.cacheAgeMs)[0]),
      rateWarning: [...new Set([...usedMeta.map(rateWarning), rateFailure].filter(Boolean))].join(" ") || null,
      rateFailure,
      scanLimited: textScan.limited,
      scannedTextNodes: textScan.nodes.length,
      inspectedTextNodes: textScan.inspected,
      error: count === 0
        ? rateError?.error || t("convert.noneConverted")
        : undefined,
      // A rate outage is not the website's fault, so it offers no report.
      reportReason: count === 0 && !rateError ? "failed" : null
    };
  }

  function buildNoMatchesResult(textPlans, splitPlans) {
    const detection = CurrencyDetector.getPageCurrencyDetection();
    const sameAsTarget = settings.fromCurrency === "AUTO" && detection.currency === settings.toCurrency;
    const autoDetectionFailed = settings.fromCurrency === "AUTO" &&
      (!detection.currency || detection.confidence === "low");
    return {
      ok: false,
      count: 0,
      detectedCurrency: detection.currency,
      detectionConfidence: detection.confidence,
      detectedCurrencies: CurrencyDetector.describeDetectedCurrencies(textPlans, splitPlans),
      error: sameAsTarget
        ? t("convert.sameAsTarget", { currency: settings.toCurrency })
        : autoDetectionFailed
          ? t("convert.lowConfidence")
          : settings.fromCurrency !== "AUTO"
            ? t("convert.manualNotFound", { currency: settings.fromCurrency })
            : t("convert.noPrices"),
      // Which kind of "Report this website" fits. A page already in the target
      // currency is working as intended, so it offers none.
      reportReason: sameAsTarget ? null : autoDetectionFailed ? "no-currency" : "no-prices"
    };
  }

  async function convertSelectionText(selectedText, element) {
    if (!settings?.enabled) return { ok: false, error: t("error.off") };
    const generation = conversionGeneration;
    const runSettings = settings;
    const matches = CurrencyDetector.findMatchesForContext(
      selectedText,
      element,
      runSettings,
      { selection: true }
    );
    if (matches.length > 1) {
      return { ok: false, error: t("convert.selectOne") };
    }
    const match = matches[0];

    if (!match) {
      // A price that is already in the target currency is not "unidentified": say so.
      const alreadyTarget = CurrencyDetector.findMatchesForContext(
        selectedText,
        element,
        runSettings,
        { selection: true, keepTarget: true }
      );
      if (alreadyTarget.length === 1 && alreadyTarget[0].currency === runSettings.toCurrency) {
        return {
          ok: false,
          error: t("convert.selectionSameAsTarget", { currency: runSettings.toCurrency })
        };
      }
      return {
        ok: false,
        error: settings.fromCurrency === "AUTO"
          ? t("convert.selectionUnknown")
          : t("convert.selectionMismatch", { currency: settings.fromCurrency })
      };
    }

    const ratesResult = await ensureRates(match.currency);
    if (!isCurrentRun(generation, runSettings)) {
      return { ok: false, cancelled: true, error: t("convert.selectionCancelled") };
    }
    if (!ratesResult?.ok) return ratesResult;
    const meta = activeRateMetaByBase[match.currency] || {};
    return {
      ok: true,
      original: selectedText,
      sourceCurrency: match.currency,
      converted: convertAmount(match.amount, match.currency),
      rateDate: meta.date || null,
      staleRates: Boolean(meta.stale),
      rateProvider: meta.provider || null,
      cacheAgeLabel: cacheAgeLabel(meta),
      rateWarning: rateWarning(meta)
    };
  }

  function normalizeRoots(roots) {
    const expanded = new Set();
    for (const root of roots.filter(Boolean)) collectOpenRoots(root, expanded);
    const unique = [...expanded].filter((root) => root.isConnected !== false);
    return unique.filter((root, index) => !unique.some((other, otherIndex) =>
      index !== otherIndex && other !== root && other.nodeType === Node.ELEMENT_NODE &&
      !root.host && other.contains?.(root)
    ));
  }

  function detectPagePrices({ roots = null } = {}) {
    if (!settings?.enabled || !document.body) return { found: false, currencies: [] };
    const scanRoots = normalizeRoots(roots || [document.body]);
    const priceElements = new Set();

    for (const root of scanRoots) {
      if (![Node.ELEMENT_NODE, Node.DOCUMENT_FRAGMENT_NODE].includes(root.nodeType) || isOwnedElement(root)) continue;
      if (root.matches?.(SPLIT_CANDIDATE_SELECTOR)) priceElements.add(root);
      for (const element of root.querySelectorAll?.(SPLIT_CANDIDATE_SELECTOR) || []) {
        priceElements.add(element);
        if (priceElements.size >= MAX_DISCOVERY_PRICE_ELEMENTS) break;
      }
      if (priceElements.size >= MAX_DISCOVERY_PRICE_ELEMENTS) break;
    }

    const prioritizedPriceElements = [...priceElements];
    prioritizeViewportElements(prioritizedPriceElements);
    for (const element of prioritizedPriceElements) {
      if (
        element.closest("[hidden], [inert], [aria-hidden='true'], template") ||
        element.isContentEditable ||
        !isRendered(element) ||
        element.closest(`${OWNED_SELECTOR}, ${UI_SELECTOR}`)
      ) continue;
      const text = element.textContent?.trim();
      if (!text || text.length > 120) continue;
      const matches = CurrencyDetector.findMatchesForContext(splitPriceText(element, text), element, settings);
      const currencies = usableDiscoveryCurrencies(matches);
      if (currencies.length) return { found: true, currencies };
    }

    let inspected = 0;
    for (const root of scanRoots) {
      if (root.nodeType === Node.TEXT_NODE) {
        const currencies = discoveryCurrenciesForTextNode(root);
        if (currencies.length) return { found: true, currencies };
        continue;
      }
      if (![Node.ELEMENT_NODE, Node.DOCUMENT_FRAGMENT_NODE].includes(root.nodeType) || isOwnedElement(root)) continue;
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      while (walker.nextNode() && inspected < MAX_DISCOVERY_TEXT_NODES) {
        inspected += 1;
        const currencies = discoveryCurrenciesForTextNode(walker.currentNode);
        if (currencies.length) return { found: true, currencies };
      }
      if (inspected >= MAX_DISCOVERY_TEXT_NODES) break;
    }
    return { found: false, currencies: [] };
  }

  function discoveryCurrenciesForTextNode(node) {
    if (!acceptTextNode(node)) return [];
    return usableDiscoveryCurrencies(CurrencyDetector.findMatchesForContext(
      node.nodeValue,
      node.parentElement,
      settings
    ));
  }

  function usableDiscoveryCurrencies(matches) {
    return [...new Set((matches || [])
      .map((match) => match.currency)
      .filter((currency) => currency && currency !== settings.toCurrency))];
  }

  function prefetchRates(currencies) {
    const bases = [...new Set(currencies || [])]
      .filter((currency) => currency && currency !== settings?.toCurrency)
      .slice(0, 3);
    if (!bases.length) return Promise.resolve([]);
    return Promise.allSettled(bases.map(ensureRates));
  }

  // Read-only view of an already-loaded rate, for surfaces that want to show what
  // a conversion would give before the user commits to it. Never fetches.
  function describeRate(baseCurrency) {
    const rate = activeRatesByBase[baseCurrency]?.[settings?.toCurrency];
    if (!Number.isFinite(rate)) return null;
    const meta = activeRateMetaByBase[baseCurrency] || {};
    return {
      base: baseCurrency,
      quote: settings.toCurrency,
      rate,
      date: meta.date || null,
      stale: Boolean(meta.stale),
      cacheAgeLabel: cacheAgeLabel(meta)
    };
  }

  // Rate details are worded when shown, not when fetched, so a language change on
  // the open page reaches them too.
  function cacheAgeLabel(meta) {
    return meta?.cached ? global.CurrencyI18n.age(meta.cacheAgeMs) : null;
  }

  function rateWarning(meta) {
    return global.CurrencyI18n.describe(meta.warningKey, meta.warningParams, meta.warning) || null;
  }

  function startDiscovering(onFound) {
    if (!settings?.enabled || !document.body || typeof MutationObserver === "undefined") return;
    discoveryCallback = onFound;
    discoveryScheduler.start(document.body);
  }

  function inspectDiscoveryRoots(roots) {
    if (!roots.length || !settings?.enabled) return;
    if (settings.fromCurrency === "AUTO") CurrencyDetector.resetPageCurrencyDetection();
    const detection = detectPagePrices({ roots });
    if (!detection.found) return;
    const callback = discoveryCallback;
    stopDiscovering();
    prefetchRates(detection.currencies).catch(() => {});
    callback?.(detection);
  }

  function stopDiscovering() {
    discoveryScheduler.stop();
    discoveryCallback = null;
  }

  function collectOpenRoots(root, output) {
    output.add(root);
    if (root.nodeType !== Node.ELEMENT_NODE && root.nodeType !== Node.DOCUMENT_FRAGMENT_NODE) return;
    if (root.shadowRoot) collectOpenRoots(root.shadowRoot, output);
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
    let inspected = 0;
    while (walker.nextNode() && inspected < MAX_SHADOW_HOSTS_PER_SCAN) {
      inspected += 1;
      if (walker.currentNode.shadowRoot) collectOpenRoots(walker.currentNode.shadowRoot, output);
    }
  }

  function collectTextNodes(roots) {
    const nodes = new Set();
    const splitCandidates = new Set();
    const scanState = { inspected: 0 };
    let limited = false;

    for (const root of roots) {
      if (nodes.size >= MAX_TEXT_NODES_PER_SCAN) {
        limited = true;
        break;
      }
      if (![Node.ELEMENT_NODE, Node.DOCUMENT_FRAGMENT_NODE].includes(root.nodeType) || isOwnedElement(root)) continue;
      const priceRoots = [];
      if (root.matches?.(SPLIT_CANDIDATE_SELECTOR)) priceRoots.push(root);
      for (const element of root.querySelectorAll?.(SPLIT_CANDIDATE_SELECTOR) || []) {
        priceRoots.push(element);
        if (priceRoots.length >= MAX_SPLIT_CANDIDATES_PER_SCAN) break;
      }
      prioritizeViewportElements(priceRoots);
      for (const priceRoot of priceRoots) {
        limited = collectTextNodesFromRoot(priceRoot, nodes, splitCandidates, scanState) || limited;
        if (nodes.size >= MAX_TEXT_NODES_PER_SCAN) break;
      }
    }

    for (const root of roots) {
      if (nodes.size >= MAX_TEXT_NODES_PER_SCAN) {
        limited = true;
        break;
      }
      if (root.nodeType === Node.TEXT_NODE) {
        if (acceptTextNode(root)) nodes.add(root);
        continue;
      }
      if (![Node.ELEMENT_NODE, Node.DOCUMENT_FRAGMENT_NODE].includes(root.nodeType) || isOwnedElement(root)) continue;
      limited = collectTextNodesFromRoot(root, nodes, splitCandidates, scanState) || limited;
      if (scanState.inspected >= MAX_TEXT_NODES_INSPECTED_PER_SCAN) break;
    }
    return {
      nodes: [...nodes],
      splitCandidates: [...splitCandidates],
      limited,
      inspected: scanState.inspected
    };
  }

  function collectTextNodesFromRoot(root, nodes, splitCandidates, scanState) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      scanState.inspected += 1;
      collectSplitCandidateForTextNode(walker.currentNode, splitCandidates);
      if (acceptTextNode(walker.currentNode)) {
        nodes.add(walker.currentNode);
      }
      if (nodes.size >= MAX_TEXT_NODES_PER_SCAN) return true;
      if (scanState.inspected >= MAX_TEXT_NODES_INSPECTED_PER_SCAN) return true;
    }
    return false;
  }

  function collectSplitCandidateForTextNode(node, splitCandidates) {
    const nodeText = node.nodeValue || "";
    if (
      !node.parentElement ||
      SKIP_TAGS.has(node.parentElement.tagName) ||
      !QUICK_CURRENCY_MARKER_PATTERN.test(nodeText)
    ) return;
    if (CurrencyDetector.findCurrencyMatches(nodeText, {
      pageDetection: CurrencyDetector.getPageCurrencyDetection()
    }).length) return;

    let element = node.parentElement;
    for (let level = 0; element && level < 3; level += 1, element = element.parentElement) {
      const text = element.textContent?.trim();
      if (!text || text.length > 100) continue;
      if (!POSSIBLE_PRICE_TEXT_PATTERN.test(text) || !holdsSplitPrice(element)) continue;
      const matches = CurrencyDetector.findMatchesForContext(text, element, settings);
      if (!matches.some((match) => CurrencyDetector.hasCurrencyMarker(nodeText, match.currency))) {
        continue;
      }
      splitCandidates.add(element);
      return;
    }
  }

  // A plain predicate, not a NodeFilter: no TreeWalker here is given a filter
  // callback, and returning NodeFilter constants meant a rejected node (2) read
  // as truthy wherever a caller tested the result directly.
  function acceptTextNode(node) {
    if (!node.nodeValue?.trim() || !POSSIBLE_PRICE_TEXT_PATTERN.test(node.nodeValue)) {
      return false;
    }
    const parent = node.parentElement;
    if (
      !parent ||
      SKIP_TAGS.has(parent.tagName) ||
      (!QUICK_CURRENCY_MARKER_PATTERN.test(node.nodeValue) && !CurrencyDetector.isLikelyPriceElement(parent)) ||
      parent.isContentEditable ||
      parent.closest(PRICE_FRAGMENT_SELECTOR) ||
      // Loose text beside a split price's own badge is already converted as part
      // of that price, and in converted-only mode it is still there, just unseen.
      parent.querySelector(":scope > ccp-conversion[data-ccp-appended='true']") ||
      isSplitPriceFraction(node) ||
      parent.closest("[hidden], [inert], [aria-hidden='true'], template") ||
      !isRendered(parent) ||
      parent.closest(`${OWNED_SELECTOR}, ${UI_SELECTOR}`)
    ) {
      return false;
    }
    return true;
  }

  function collectSplitPricePlans(roots, discoveredElements = []) {
    const elements = new Set(discoveredElements);
    for (const root of roots) {
      if (![Node.ELEMENT_NODE, Node.DOCUMENT_FRAGMENT_NODE].includes(root.nodeType) || isOwnedElement(root)) continue;
      if (root.matches?.(SPLIT_CANDIDATE_SELECTOR)) elements.add(root);
      for (const element of root.querySelectorAll?.(SPLIT_CANDIDATE_SELECTOR) || []) {
        elements.add(element);
        if (elements.size >= MAX_SPLIT_CANDIDATES_PER_SCAN) break;
      }
      if (elements.size >= MAX_SPLIT_CANDIDATES_PER_SCAN) break;
    }

    const plans = [];
    for (const element of [...elements].reverse()) {
      if (
        !holdsSplitPrice(element) ||
        element.matches(PRICE_FRAGMENT_SELECTOR) ||
        element.closest("[hidden], [inert], [aria-hidden='true'], template") ||
        element.isContentEditable ||
        !isRendered(element) ||
        element.closest(OWNED_SELECTOR) ||
        element.querySelector(OWNED_SELECTOR) ||
        // One badge per nested chain, in both directions. Guarding only against
        // an element that wraps a planned one left "<p><span><b>$</b>99.00</span></p>"
        // planned twice — once as the paragraph a price selector matched, once as
        // the span a split text node nominated — and drawn twice on the page.
        plans.some((plan) => element.contains(plan.element) || plan.element.contains(element))
      ) continue;

      const text = element.textContent?.trim();
      if (!text || text.length > 100) continue;
      const matches = CurrencyDetector.findMatchesForContext(splitPriceText(element, text), element, settings);
      if (!matches.length || elementHasCompletePriceNode(element)) continue;
      plans.push({ element, originalText: text, matches: [matches[0]] });
    }
    return plans;
  }

  // Amazon writes each price twice in one element: a screen-reader copy
  // (.a-offscreen, "PLN 34.98") and the visible copy split across spans. Read
  // together they run into each other, "PLN 34.98PLN34.98", and a currency code
  // then matches neither (a symbol, "$34.98$34.98", happens to survive). The
  // screen-reader copy is always whole, so it is the one to read.
  function splitPriceText(element, text) {
    return element.querySelector(":scope > .a-offscreen")?.textContent?.trim() ||
      joinSplitFraction(element) ||
      text;
  }

  // doz.pl draws "44,99 zł" as <span class="price-major">44</span>
  // <span class="price-minor">99 zł</span>, with no separator anywhere. Read as
  // text that is "44 99 zł", and the minor span alone is a whole-looking
  // "99 zł", so every tile was converted as 99 zł. Joining the parts with a
  // decimal point gives the parser the price the page shows.
  function joinSplitFraction(element) {
    let joined = "";
    let found = false;
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const value = walker.currentNode.nodeValue || "";
      if (isSplitPriceFraction(walker.currentNode)) {
        joined = `${joined.trimEnd()}.${value.trimStart()}`;
        found = true;
      } else {
        joined += value;
      }
    }
    return found ? joined.trim() : null;
  }

  // The first text of an element whose two leading digits are the fraction of
  // the bare integer in the element just before it. Both parts must be named as
  // price parts (major/minor, int/dec, whole/fraction), so "2" items beside
  // "99 zł" is not read as 2.99 zł.
  function isSplitPriceFraction(node) {
    const fraction = node.parentElement;
    if (!fraction || !SPLIT_FRACTION_START_PATTERN.test(node.nodeValue || "")) return false;
    for (let sibling = node.previousSibling; sibling; sibling = sibling.previousSibling) {
      if (sibling.nodeType !== Node.TEXT_NODE || sibling.nodeValue?.trim()) return false;
    }
    let integer = fraction.previousSibling;
    while (integer?.nodeType === Node.TEXT_NODE && !integer.nodeValue?.trim()) {
      integer = integer.previousSibling;
    }
    if (integer?.nodeType !== Node.ELEMENT_NODE) return false;
    if (!SPLIT_INTEGER_PATTERN.test(integer.textContent?.trim() || "")) return false;
    return SPLIT_PART_CLASS_PATTERN.test(
      `${integer.getAttribute("class") || ""} ${fraction.getAttribute("class") || ""}`
    );
  }

  // Whether the element's text is spread over more than one node, so no single
  // text node carries a whole price. Child elements are the obvious case, but a
  // server-rendered React amount is "66 000<!-- --> ₼": no child elements at
  // all, and two text nodes that mean nothing apart.
  function holdsSplitPrice(element) {
    if (element.childElementCount > 0) return true;
    let textNodes = 0;
    for (const child of element.childNodes) {
      if (child.nodeType !== Node.TEXT_NODE || !child.nodeValue?.trim()) continue;
      textNodes += 1;
      if (textNodes > 1) return true;
    }
    return false;
  }

  // A whole price in a single text node is left to the text pass, unless that pass
  // will never convert it: Amazon's visible "PLN17.51" sits whole inside
  // aria-hidden="true", which the text pass skips, so the element must take it.
  function elementHasCompletePriceNode(element) {
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      if (walker.currentNode.parentElement?.closest(
        `${PRICE_FRAGMENT_SELECTOR}, [hidden], [inert], [aria-hidden='true'], template`
      )) continue;
      if (isSplitPriceFraction(walker.currentNode)) continue;
      if (CurrencyDetector.findMatchesForContext(
        walker.currentNode.nodeValue || "",
        walker.currentNode.parentElement,
        settings
      ).length) return true;
    }
    return false;
  }

  function collectSourceCurrencies(...planGroups) {
    const bases = new Set();
    for (const plans of planGroups) {
      for (const plan of plans) {
        for (const match of plan.matches) {
          if (match.currency !== settings.toCurrency) bases.add(match.currency);
        }
      }
    }
    return bases;
  }

  async function ensureRates(baseCurrency) {
    if (activeRatesByBase[baseCurrency]?.[settings.toCurrency]) return { ok: true };
    const result = await ExtensionAPI.runtime.sendMessage({
      type: CurrencyMessages.GET_RATES,
      baseCurrency
    });
    if (result?.ok) {
      activeRatesByBase[baseCurrency] = result.rates;
      activeRateMetaByBase[baseCurrency] = {
        date: result.date,
        fetchedAt: result.fetchedAt,
        stale: Boolean(result.stale),
        cached: Boolean(result.cached),
        provider: result.provider,
        cacheAgeMs: result.cacheAgeMs,
        warning: result.warning,
        warningKey: result.warningKey,
        warningParams: result.warningParams
      };
    }
    return global.CurrencyI18n.localize(result) || { ok: false, error: t("convert.ratesFailed") };
  }

  function ratesCacheChangeAffectsActiveRates(change) {
    const oldBases = change?.oldValue?.bases || {};
    const newBases = change?.newValue?.bases || {};
    return Object.keys(activeRatesByBase).some((baseCurrency) => {
      const oldEntry = oldBases[baseCurrency];
      const newEntry = newBases[baseCurrency];
      if (!oldEntry && !newEntry) return false;
      if (!newEntry) return true;
      return newEntry.fetchedAt !== activeRateMetaByBase[baseCurrency]?.fetchedAt ||
        newEntry.rateDate !== activeRateMetaByBase[baseCurrency]?.date ||
        newEntry.rates?.[settings?.toCurrency] !== activeRatesByBase[baseCurrency]?.[settings?.toCurrency];
    });
  }

  async function applyPlansInBatches(textPlans, splitPlans, generation, runSettings) {
    let count = 0;
    let processed = 0;
    for (const plan of textPlans) {
      if (!isCurrentRun(generation, runSettings)) return { count, cancelled: true };
      count += applyTextPlan(plan);
      processed += 1;
      if (processed % DOM_WRITE_BATCH_SIZE === 0) {
        await yieldToMainThread();
        if (!isCurrentRun(generation, runSettings)) return { count, cancelled: true };
      }
    }
    for (const plan of splitPlans) {
      if (!isCurrentRun(generation, runSettings)) return { count, cancelled: true };
      count += applySplitPlan(plan);
      processed += 1;
      if (processed % DOM_WRITE_BATCH_SIZE === 0) {
        await yieldToMainThread();
        if (!isCurrentRun(generation, runSettings)) return { count, cancelled: true };
      }
    }
    return { count, cancelled: false };
  }

  function isCurrentRun(generation, runSettings) {
    return generation === conversionGeneration && settings?.enabled && runSettings?.enabled;
  }

  function cancelledConversionResult() {
    return {
      ok: false,
      count: 0,
      cancelled: true,
      error: t("convert.cancelled")
    };
  }

  function yieldToMainThread() {
    return new Promise((resolve) => window.setTimeout(resolve, 0));
  }

  function applyTextPlan({ node, originalText, matches }) {
    if (!node.parentNode || node.nodeValue !== originalText) return 0;
    const usable = matches.filter((match) => activeRatesByBase[match.currency]?.[settings.toCurrency]);
    if (!usable.length) return 0;

    const text = node.nodeValue;
    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    for (const match of usable) {
      fragment.append(document.createTextNode(text.slice(lastIndex, match.index)));
      fragment.append(buildConvertedNode(match));
      lastIndex = match.index + match.raw.length;
    }
    fragment.append(document.createTextNode(text.slice(lastIndex)));
    node.parentNode.replaceChild(fragment, node);
    return usable.length;
  }

  function applySplitPlan({ element, originalText, matches }) {
    if (!element.isConnected || element.closest(OWNED_SELECTOR) || element.querySelector(OWNED_SELECTOR)) {
      return 0;
    }
    if (element.textContent?.trim() !== originalText) return 0;
    const match = matches.find((candidate) => activeRatesByBase[candidate.currency]?.[settings.toCurrency]);
    if (!match) return 0;

    const displayMode = normalizeDisplayMode(settings);
    const badge = document.createElement("ccp-conversion");
    badge.dataset.ccpOwned = "true";
    badge.dataset.ccpAppended = "true";
    badge.dataset.sourceCurrency = match.currency;
    badge.dataset.displayMode = displayMode;
    badge.className = "ccp-conversion";
    badge.style.setProperty("display", "inline", "important");
    badge.appendChild(createConvertedBadge(match, { adjacent: displayMode !== "replace" }));
    element.appendChild(badge);
    if (displayMode === "replace") hideOriginalContent(badge, element);
    conversionRegistry.add(badge);
    splitPriceRecords.set(element, { badge, originalText });
    return 1;
  }

  // A split price is drawn across nodes the extension does not own, so "converted
  // only" cannot simply hide a wrapper it created. Those nodes stay where the shop
  // put them: moving them into the badge, as before, broke shops whose framework
  // (React, Vue) later inserted or removed them under their old parent. Element
  // children are hidden with an inline style. Loose text takes no style of its own:
  // the host is made invisible (which takes it out of the rendered text and the
  // accessibility tree) and zero-sized (which takes its space), while the badge is
  // made visible again at the host's size. Every inline value is recorded so Undo
  // puts back exactly what was there.
  function hideOriginalContent(badge, host) {
    if (!host || hiddenOriginals.has(badge)) return;
    const record = { host, styles: [] };
    let hasLooseText = false;
    for (const child of host.childNodes) {
      if (child === badge) continue;
      if (child.nodeType === Node.ELEMENT_NODE && child.style) {
        record.styles.push(overrideStyle(child, "display", "none"));
      } else if (child.nodeType === Node.TEXT_NODE && child.nodeValue?.trim()) {
        hasLooseText = true;
      }
    }
    if (hasLooseText) {
      const fontSize = window.getComputedStyle(host).fontSize;
      record.styles.push(overrideStyle(badge, "font-size", fontSize));
      record.styles.push(overrideStyle(badge, "visibility", "visible"));
      record.styles.push(overrideStyle(host, "font-size", "0"));
      record.styles.push(overrideStyle(host, "visibility", "hidden"));
    }
    hiddenOriginals.set(badge, record);
  }

  function releaseOriginalContent(badge) {
    const record = hiddenOriginals.get(badge);
    if (!record) return;
    hiddenOriginals.delete(badge);
    for (const saved of record.styles.reverse()) restoreStyle(saved);
  }

  function releaseAllOriginalContent() {
    for (const badge of [...hiddenOriginals.keys()]) releaseOriginalContent(badge);
  }

  function overrideStyle(element, property, value) {
    const saved = {
      element,
      property,
      value: element.style.getPropertyValue(property),
      priority: element.style.getPropertyPriority(property),
      hadStyleAttribute: element.hasAttribute("style")
    };
    element.style.setProperty(property, value, "important");
    return saved;
  }

  function restoreStyle({ element, property, value, priority, hadStyleAttribute }) {
    if (value) element.style.setProperty(property, value, priority);
    else element.style.removeProperty(property);
    if (!hadStyleAttribute && element.getAttribute("style") === "") element.removeAttribute("style");
  }

  function normalizeDisplayMode(value) {
    return value?.displayMode === "replace" ? "replace" : "beside";
  }

  function buildConvertedNode(match) {
    const displayMode = normalizeDisplayMode(settings);
    const wrapper = document.createElement("ccp-conversion");
    wrapper.dataset.ccpOwned = "true";
    wrapper.dataset.sourceCurrency = match.currency;
    wrapper.dataset.displayMode = displayMode;
    wrapper.className = "ccp-conversion";
    wrapper.style.setProperty("display", "inline", "important");
    const original = document.createElement("span");
    original.className = "ccp-original";
    original.textContent = match.raw;
    original.style.setProperty(
      "display",
      displayMode === "replace" ? "none" : "inline",
      "important"
    );
    const converted = createConvertedBadge(match, {
      adjacent: displayMode !== "replace"
    });
    wrapper.append(original, converted);
    conversionRegistry.add(wrapper);
    return wrapper;
  }

  function createConvertedBadge(match, { adjacent }) {
    const converted = document.createElement("span");
    converted.className = "ccp-badge";
    converted.textContent = `≈ ${convertAmount(match.amount, match.currency)}`;
    converted.title = conversionTitle(match.currency);
    applyConvertedAppearance(converted, { adjacent });
    return converted;
  }

  function applyConvertedAppearance(converted, { adjacent }) {
    const appearance = CurrencySettings.normalizeAppearance(settings);
    const shape = appearance.convertedShape;

    converted.dataset.ccpShape = shape;
    for (const [property, value] of Object.entries({
      display: "inline-block",
      color: appearance.convertedTextColor,
      "background-color": appearance.convertedBackgroundColor,
      "border-radius": CurrencySettings.SHAPE_RADII[shape],
      "font-weight": "700",
      "margin-inline-start": adjacent ? "0.28em" : "0",
      padding: "0.08em 0.34em",
      "white-space": "nowrap"
    })) {
      converted.style.setProperty(property, value, "important");
    }
  }

  function updateConvertedPresentation(wrapper, nextSettings) {
    const appended = wrapper.dataset.ccpAppended === "true";
    const displayMode = normalizeDisplayMode(nextSettings);
    wrapper.dataset.displayMode = displayMode;
    if (appended) {
      if (displayMode === "replace") hideOriginalContent(wrapper, wrapper.parentElement);
      else releaseOriginalContent(wrapper);
    } else {
      wrapper.querySelector(".ccp-original")?.style.setProperty(
        "display",
        displayMode === "replace" ? "none" : "inline",
        "important"
      );
    }
    const converted = wrapper.querySelector(".ccp-badge");
    if (converted) applyConvertedAppearance(converted, {
      adjacent: displayMode !== "replace"
    });
  }

  function conversionTitle(baseCurrency) {
    const meta = activeRateMetaByBase[baseCurrency] || {};
    const rate = activeRatesByBase[baseCurrency]?.[settings.toCurrency];
    const provider = meta.provider ? ` ${t("convert.titleProvider", { provider: meta.provider })}` : "";
    const exchangeRate = Number.isFinite(rate)
      ? ` ${t("convert.titleRate", {
        base: baseCurrency,
        rate: global.CurrencyI18n.formatRate(rate),
        target: settings.toCurrency
      })}`
      : "";
    const date = meta.date ? ` ${t("convert.titleDate", { date: meta.date })}` : "";
    const age = cacheAgeLabel(meta);
    const stale = meta.stale
      ? ` ${t(age ? "rate.cachedAge" : "rate.cached", { age })}`
      : "";
    const base = t("convert.titleBase", { base: baseCurrency, target: settings.toCurrency });
    return `${base}${exchangeRate}${provider}${date}${stale}`;
  }

  function convertAmount(amount, baseCurrency) {
    const rate = activeRatesByBase[baseCurrency]?.[settings.toCurrency];
    return CurrencyCatalog.formatCurrencyAmount(amount * rate, settings.toCurrency);
  }

  function startWatching() {
    if (!document.body || typeof MutationObserver === "undefined") return;
    if (conversionScheduler.start(document.body)) observedUrl = window.location.href;
  }

  function handleObservedMutations(mutations, scheduler) {
    if (!settings?.enabled) return;
    let hasSiteMutation = mutations.some((mutation) => !isOwnedElement(
      mutation.target.nodeType === Node.TEXT_NODE ? mutation.target.parentElement : mutation.target
    ));
    for (const mutation of mutations) {
      if (mutation.type === "attributes") continue;
      let host = mutation.target.nodeType === Node.TEXT_NODE
        ? mutation.target.parentElement : mutation.target;
      for (; host; host = host.parentElement) {
        const record = splitPriceRecords.get(host);
        if (!record) continue;
        const currentText = [...host.childNodes].filter((node) => node !== record.badge)
          .map((node) => node.textContent).join("").trim();
        if (currentText !== record.originalText || !host.contains(record.badge)) {
          hasSiteMutation = true;
          splitPriceRecords.delete(host);
          // Released first: a badge the shop already removed is no longer connected,
          // and the registry skips it, but the nodes it hid are still hidden.
          releaseOriginalContent(record.badge);
          conversionRegistry.restore(record.badge);
          scheduler.queue(host);
        }
        break;
      }
    }
    if (hasSiteMutation && window.location.href !== observedUrl) {
      observedUrl = window.location.href;
      CurrencyDetector.resetPageCurrencyDetection();
      scheduler.queue(document.body);
    }
  }

  async function convertMutationRoots(roots) {
    if (!roots.length || !settings?.enabled) return;
    if (settings.fromCurrency === "AUTO") CurrencyDetector.resetPageCurrencyDetection();
    const result = await runSiteConversion({ clearExisting: false, observe: true, roots })
      .catch(() => null);
    if (result?.ok && result.count > 0) watchedConversionListener?.();
  }

  // Prices a shop loads after the first pass are converted here, out of sight of
  // the content script, which still needs to know the page was helped.
  function onWatchedConversion(listener) {
    watchedConversionListener = listener;
  }

  function isOwnedElement(element) {
    return Boolean(element?.matches?.(`${OWNED_SELECTOR}, ${UI_SELECTOR}`) ||
      element?.closest?.(`${OWNED_SELECTOR}, ${UI_SELECTOR}`));
  }

  function stopWatching() {
    conversionScheduler.stop();
  }

  function isRendered(element) {
    const style = window.getComputedStyle?.(element);
    if (style && (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse")) {
      return false;
    }
    if (typeof element.getClientRects === "function" && element.getClientRects().length > 0) return true;
    try {
      const range = element.ownerDocument?.createRange?.();
      if (!range) return false;
      range.selectNodeContents(element);
      return range.getClientRects().length > 0;
    } catch (_error) {
      return false;
    }
  }

  function prioritizeViewportElements(elements) {
    const viewportState = new Map(elements.map((element) => [element, isInViewport(element)]));
    elements.sort((a, b) => Number(viewportState.get(b)) - Number(viewportState.get(a)));
  }

  function isInViewport(element) {
    const rect = element.getBoundingClientRect?.();
    return Boolean(rect && rect.bottom >= 0 && rect.right >= 0 &&
      rect.top <= window.innerHeight && rect.left <= window.innerWidth);
  }

  function removeConversionsOnly() {
    conversionRegistry.restoreAll();
    releaseAllOriginalContent();
    splitPriceRecords = new WeakMap();
  }

  function clearConversions() {
    cancelPendingConversion();
    stopWatching();
    removeConversionsOnly();
  }

  function cancelPendingConversion() {
    conversionGeneration += 1;
    conversionScheduler.clearPending();
    if (queuedConversion) {
      const result = cancelledConversionResult();
      for (const waiter of queuedConversion.waiters) waiter.resolve(result);
      queuedConversion = null;
    }
  }

  function hasConversions() {
    return conversionRegistry.hasAny();
  }

  global.CurrencyPageConverter = Object.freeze({
    configure,
    updatePresentation,
    runSiteConversion,
    convertSelectionText,
    clearConversions,
    cancelPendingConversion,
    hasConversions,
    detectPagePrices,
    prefetchRates,
    describeRate,
    ratesCacheChangeAffectsActiveRates,
    startDiscovering,
    stopDiscovering,
    startWatching,
    stopWatching,
    onWatchedConversion
  });
})(globalThis);
