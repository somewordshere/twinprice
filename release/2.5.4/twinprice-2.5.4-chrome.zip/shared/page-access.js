(function initializePageAccess(global) {
  const FIREFOX_RESTRICTED_HOSTS = new Set([
    "accounts-static.cdn.mozilla.net",
    "accounts.firefox.com",
    "addons.cdn.mozilla.net",
    "addons.mozilla.org",
    "api.accounts.firefox.com",
    "content.cdn.mozilla.net",
    "discovery.addons.mozilla.org",
    "install.mozilla.org",
    "oauth.accounts.firefox.com",
    "profile.accounts.firefox.com",
    "support.mozilla.org",
    "sync.services.mozilla.com"
  ]);

  // The popup loads the translations. The background loads the translator only to
  // work out a language, without any dictionaries, so it keeps English: a missing
  // entry comes back as its own key.
  function text(key, fallback, params) {
    const translated = global.CurrencyI18n ? global.CurrencyI18n.t(key, params) : key;
    return translated === key ? fallback : translated;
  }

  const UNSUPPORTED_PAGE_TEXT = Object.freeze({
    "access.noWebpage": "This tab does not have a webpage that can be converted.",
    "access.pdf": "Extensions cannot run inside the browser's PDF viewer. Open a regular webpage and try again.",
    "access.browserPage": "Extensions cannot run on browser pages, Reader View, PDFs, or other extension pages.",
    "access.firefoxProtected": "Firefox protects this Mozilla page from extensions. Open a regular shopping page and try again."
  });

  // The translation key for why a page cannot be converted, or null when it can.
  // The background sends the key along with the English text it can produce itself.
  function unsupportedPageKey(urlValue) {
    const url = parseUrl(urlValue);
    if (!url) return "access.noWebpage";
    if (["file:", "http:", "https:"].includes(url.protocol) && hasPdfPath(url)) return "access.pdf";
    if (url.protocol === "file:") return null;
    if (url.protocol !== "http:" && url.protocol !== "https:") return "access.browserPage";
    if (isFirefoxBuild() && FIREFOX_RESTRICTED_HOSTS.has(url.hostname.toLowerCase())) {
      return "access.firefoxProtected";
    }
    return null;
  }

  function unsupportedPageMessage(urlValue) {
    const key = unsupportedPageKey(urlValue);
    return key ? text(key, UNSUPPORTED_PAGE_TEXT[key]) : null;
  }

  function describeFailure(tab, error) {
    const unsupported = unsupportedPageMessage(tab?.url);
    if (unsupported) return unsupported;

    const detail = normalizeError(error);
    if (detail) {
      return text("access.startFailed", `Could not start conversion on this page. ${detail}`, { detail });
    }
    return text(
      "access.startFailedReload",
      "Could not start conversion on this page. Reload it once and try again."
    );
  }

  function normalizeError(error) {
    const message = typeof error?.message === "string"
      ? error.message
      : typeof error === "string"
        ? error
        : "";
    return message.trim().replace(/^Error:\s*/i, "");
  }

  function parseUrl(value) {
    try {
      return new URL(value);
    } catch (_error) {
      return null;
    }
  }

  function hasPdfPath(url) {
    let pathname = url.pathname;
    try {
      pathname = decodeURIComponent(pathname);
    } catch (_error) {
      // A malformed escape should fall back to the undecoded pathname.
    }
    return /\.pdf$/i.test(pathname);
  }

  function isFirefoxBuild() {
    try {
      return Boolean(
        global.ExtensionAPI?.runtime?.getManifest?.()?.browser_specific_settings?.gecko
      );
    } catch (_error) {
      return false;
    }
  }

  global.CurrencyPageAccess = Object.freeze({
    describeFailure,
    isFirefoxBuild,
    unsupportedPageKey,
    unsupportedPageMessage
  });
})(globalThis);
